DELETE SCHEMA datenspende;

DROP TABLE datenspende.users;

DROP TABLE datenspende.answers;

DROP TABLE datenspende.questionnaires;

DROP TABLE datenspende.questionnaire_session;

DROP TABLE datenspende.questions;

DROP TABLE datenspende.question_to_questionnaire;

DROP TABLE datenspende.study_overview;