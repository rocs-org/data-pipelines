-- depends: 20210726_01_QvjMc-test-migration

DROP TABLE `coronacases`.`german_counties_more_info`;