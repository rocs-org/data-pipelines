-- 
-- depends: 20210809_01_add_census_schema

DROP TABLE censusdata.nuts;