
DELETE SCHEMA coronacases;