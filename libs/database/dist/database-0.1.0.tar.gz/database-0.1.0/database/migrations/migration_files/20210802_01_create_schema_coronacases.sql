
CREATE SCHEMA coronacases;