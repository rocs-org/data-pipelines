# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['database',
 'database.migrations',
 'database.migrations.migration_files',
 'database.migrations.migration_tests']

package_data = \
{'': ['*']}

install_requires = \
['psycopg2-binary>=2.9.1,<3.0.0',
 'ramda>=2021.10.24,<2022.0.0',
 'six>=1.16.0,<2.0.0',
 'yoyo-migrations>=7.3.2,<8.0.0']

setup_kwargs = {
    'name': 'database',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Jakob J. Kolb',
    'author_email': 'kolb@hardfork.io',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
