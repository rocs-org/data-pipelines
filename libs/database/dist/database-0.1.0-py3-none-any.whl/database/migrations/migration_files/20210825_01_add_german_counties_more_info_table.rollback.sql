DROP TABLE censusdata.german_counties_info;
